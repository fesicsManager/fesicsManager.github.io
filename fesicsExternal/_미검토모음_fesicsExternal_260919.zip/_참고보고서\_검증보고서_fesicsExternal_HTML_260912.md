# fesicsExternal HTML 실험 파일 검증보고서

- 검증일: 2026-09-12
- 누적 검증 범위: 초등 3~4학년 및 5~6학년 기본/심화 16개 폴더, 중학교 1학년 3개 폴더, 중학교 2학년 기본/심화 8개 폴더, 중학교 3학년 기본/심화 8개 폴더, 고등학교 13개 폴더, 대학교 2개 폴더, HTML 405개
- 원본 처리: Google Drive 원본 변경 없음
- 검사: 파일 구성, JavaScript 구문, DOM 요소 참조, 상호작용 코드, 과학 내용, 모바일 대응 CSS, 접근성

## 전체 요약

| 등급 | 건수 | 설명 |
|---|---:|---|
| 오류 | 83개 파일 | 기능 고장 또는 핵심 과학 결론 수정 필요 |
| 개선 필요 | 165개 파일 | 표현·모형·접근성 보완 권장 |
| 양호 | 157개 파일 | 이번 정적 검사에서 중대한 문제 없음 |

JavaScript 구문은 누적 405개 파일 모두 통과했다. 다만 정적 검사에서 실행을 방해하는 DOM 참조 문제와 중복 ID, 과학적 조건이 빠진 수식·일반화가 확인됐다. 마지막으로 추가한 대학 5개 파일은 중복 ID·고정 DOM 참조·접근성 이름 없는 입력 요소가 없었으며, 3개 파일에서 불확도 처리와 모형 설명 보완이 필요했다.

## 우선 수정 사항

### 1. `01_animal_physics_lab.html` — 오류

- `resetCamel()`이 없는 요소 `camelAddBtn`의 `disabled`를 변경한다.
- `resetBear()`가 없는 요소 `bearAddBtn`의 `disabled`를 변경한다.
- `resetShape()`가 없는 요소 `shapeAddBtn`의 `disabled`를 변경한다.
- 따라서 낙타·북극곰 슬라이더를 움직이거나 몸 형태 버튼을 선택하면 `null.disabled` 오류가 발생한다.
- 현재 실제 버튼 ID는 각각 `camelStepBtn`, `bearStepBtn`, `shapeStepBtn`이다. 세 참조를 실제 ID로 고치거나 불필요한 줄을 삭제해야 한다.
- `동물의 무게: 800`에는 단위가 없다. 압력을 다룬다면 무게를 N으로 명시하고 압력 단위도 정해야 한다.
- `깊이(cm) = 800/면적(cm²)`은 실제 모래 침하 법칙이 아니라 임의의 단순 모형이다. 화면에 `단순 비례 모형`임을 분명히 표시해야 한다.
- 북극곰의 `체온 손실 속도(°C/시간)`도 임의식이므로 실제 측정값처럼 제시하지 않는 편이 안전하다.
- 세 현상을 하나의 규칙인 “표면을 넓게 퍼뜨리거나 매끄럽게 만들면 압력·열손실·저항이 줄어든다”로 묶은 문장은 부정확하다. 발 면적, 보온층 두께, 유선형은 서로 다른 원리로 나누어 정리해야 한다.

### 2. `05_egg_laying_animals_lab.html` — 과학 내용 오류

- `daysOf(T) = 21 - (T - 37.5)`로 35~40°C 전 범위에서 무조건 부화하고, 온도 1°C 상승마다 정확히 1일 빨라지는 것으로 계산한다.
- 실제 부화는 최적 온도 범위가 있으며 지나치게 낮거나 높으면 발생 이상·부화율 저하·폐사가 생길 수 있다. 단순 선형 관계를 일반 법칙이나 측정값으로 제시하면 안 된다.
- `따뜻할수록 부화가 빨라진다` 대신 `알맞은 온도 범위에서 정상적으로 발생하며, 범위를 벗어나면 부화가 어려워질 수 있다`로 바꾸는 것이 적절하다.
- `닭이 알을 품을 때의 온도는 약 37.5°C`는 `닭 알의 적정 부화 온도는 약 37.5°C`로 표현하는 편이 정확하다.
- 40°C에서도 정상 부화 결과를 내는 현재 시뮬레이션은 수정이 필요하다.

### 3. `06_live_birth_animals_lab.html` — 과학 결론 오류

- 선택한 3종씩의 평균만으로 `태생 동물이 난생 동물보다 자라는 기간이 대체로 길다`고 일반화한다. 종에 따른 변이가 매우 커 태어나는 방식만으로 기간의 길고 짧음을 판단할 수 없다.
- 해당 객관식 문항은 삭제하거나 `동물의 종류에 따라 다르므로 태어나는 방식만으로 판단할 수 없다`를 정답으로 바꿔야 한다.
- 닭·거북·개구리를 모두 같은 단단한 달걀 모양과 같은 부화 장면으로 보여준다. 특히 개구리알은 젤状 알덩이이며 올챙이가 나오므로 시각 표현을 분리해야 한다.
- `모두 다시 새끼를 낳습니다`는 난생까지 포함하므로 `모두 번식하여 다음 세대로 이어집니다`가 더 정확하다.

## 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_animal_habitats_lab.html` | 양호 | 구문·요소 참조 정상. 주요 초등 과학 설명도 대체로 적절함 |
| `01_animal_physics_lab.html` | 오류 | 존재하지 않는 버튼 ID 3개 참조, 상호작용 오류 및 단위·모형 설명 문제 |
| `02_animal_biomimicry_lab.html` | 개선 필요 | 잠자리→헬리콥터를 직접 생체모방으로 단정하기보다 기능 비교로 표현 권장. 날개 양력 설명도 압력 차와 공기 흐름 변화 중심으로 보완 |
| `03_plant_leaves_habitats_lab.html` | 양호 | 구문·요소 참조 정상. 주요 내용 적절함 |
| `04_plant_biomimicry_lab.html` | 개선 필요 | 단풍나무 씨→프로펠러를 직접 모방 관계로 단정하지 말고 회전 원리 비교로 표현 권장 |
| `05_egg_laying_animals_lab.html` | 오류 | 부화 기간을 온도에 대한 단순 직선식으로 일반화하고 40°C에서도 정상 부화 처리 |
| `06_live_birth_animals_lab.html` | 오류 | 난생·태생과 발생 기간 관계를 잘못 일반화, 개구리·거북 부화 장면 부정확 |
| `07_seed_germination_lab.html` | 개선 필요 | 강낭콩의 날짜별 단계와 1.4cm/일을 고정값으로 표시. 환경에 따른 차이 및 단순 모형임을 안내해야 함 |
| `08_plant_lifecycle_summary_lab.html` | 개선 필요 | 1~12주 단계를 특정 강낭콩 모형으로 명시하고 재배 환경에 따라 달라짐을 안내해야 함 |

## 공통 기술 개선 사항

- `01_animal_habitats`부터 `08_plant_lifecycle_summary`까지 공통 템플릿 8개는 정지 상태에서도 `requestAnimationFrame`으로 캔버스를 계속 다시 그린다. 모바일 배터리와 CPU 사용량을 줄이려면 실제 애니메이션 중에만 반복하고, 정지 상태에서는 한 번만 그리는 구조가 좋다.
- 모든 파일이 Google Fonts에 의존한다. 인터넷이 끊기면 대체 글꼴로 표시되므로 오프라인 수업을 지원하려면 글꼴을 포함하거나 시스템 글꼴 우선 대체 구성을 점검해야 한다.
- `01_animal_physics`, `05_egg_laying_animals`, `07_seed_germination`, `08_plant_lifecycle_summary`의 슬라이더·숫자 입력에는 프로그램이 인식할 수 있는 `label` 또는 `aria-label`이 부족하다.
- 캔버스 기반 실험은 화면낭독기용 대체 설명 또는 결과 텍스트가 필요하다.
- 반응형 CSS와 640px 이하 단일 열 전환은 포함되어 있다. 다만 실제 모바일 렌더링 검사는 현재 검증 환경의 Chromium 설치 제한으로 완료하지 못했으므로 후속 브라우저 검사가 필요하다.

## 검사 통과 항목

- HTML 9개 모두 다운로드 및 원본 크기 확인 완료
- JavaScript 인라인 스크립트 9개 모두 구문 검사 통과
- 중복 ID 없음
- 정적 이미지 외부 파일 누락 없음
- 외부 의존성은 Google Fonts만 확인됨
- 주요 캔버스가 CSS에서 `width:100%; height:auto`로 설정됨
- 640px 이하에서 주요 2열 레이아웃을 1열로 바꾸는 미디어 쿼리 존재

## 2차 검증: `elem34BioAdv`

### `05_animal_sorting_lab.html` — 개선 필요

- JavaScript 구문, 정적 요소 참조, 중복 ID 검사에서 오류가 없었다.
- `물속에서 살 수 있나요?`에 `거북`을 항상 참으로 지정했다. 거북류에는 육지에서 사는 종도 있으므로 `물에서 생활할 수 있나요? — 이 활동에서는 물거북을 뜻함`처럼 대상을 명확히 해야 한다.
- 좋은 분류 질문의 기준을 `네 칸에 고르게 나뉘는가`로만 설명한다. 빠르게 대상을 찾는 스무고개에서는 정보량이 큰 질문이 유리하지만, 생물 분류에서는 관찰 가능한 특징과 분류 목적도 중요하다. `이 활동에서는 여덟 동물을 빠르게 찾기 위해 고르게 나누는 질문을 좋은 질문으로 정한다`는 조건을 밝혀야 한다.
- `날개가 있나요?`와 `날 수 있나요?`가 거의 같은 질문이라고 설명하는 부분은 제시된 여덟 동물 안에서는 성립하지만, 타조·펭귄처럼 날개가 있어도 날지 못하는 동물이 있다. `이 동물 목록에서는`이라는 한정 문구가 필요하다.

### `07_seed_fair_test_lab.html` — 오류

- JavaScript 구문, 정적 요소 참조, 중복 ID 검사에서 오류가 없었다.
- 제목과 화면은 `씨앗` 전체를 대상으로 하지만 코드가 `물 O + 따뜻함 O이면 발아하며 빛은 무관`으로 고정되어 있다.
- 씨앗의 빛 요구성은 식물 종류에 따라 다르다. 많은 큰 씨앗은 빛 없이 발아하지만, 일부 씨앗은 빛이 발아를 촉진하거나 어둠이 필요한 경우도 있다. 따라서 모든 씨앗의 일반 법칙처럼 제시하면 안 된다.
- 앞 화와 연계해 `강낭콩 씨앗은 무엇이 있어야 싹틀까`로 제목과 설명을 한정하면 현재 모형을 대부분 유지할 수 있다.
- `따뜻함 O/X`는 온도가 불명확하다. `알맞은 온도(예: 20~25°C)`와 `너무 낮은 온도`처럼 조건을 수치 또는 명확한 범주로 제시해야 공정한 비교가 된다.
- 한 번의 비교 결과만으로 원인을 확정하는 표현은 `이 실험 결과는 물이 필요하다는 결론을 뒷받침한다`로 완화하고, 같은 조건의 씨앗 여러 개를 사용하거나 반복 실험한다는 안내를 추가하는 것이 좋다.

### 2차 검사 통과 항목

- HTML 2개 모두 JavaScript 구문 검사 통과
- 존재하지 않는 고정 ID 참조 없음
- 중복 ID 없음
- 표 영역에 가로·세로 스크롤 대응 CSS 포함
- 700px 이하에서 주요 2열 화면을 1열로 바꾸는 반응형 CSS 포함
- 정지 상태의 무한 캔버스 재그리기는 없어 앞 폴더보다 모바일 성능 구조가 양호함

## 3차 일괄 검증: 화학·지구과학·물리 6개 폴더

- 범위: `elem34Chem` 9개, `elem34ChemAdv` 2개, `elem34Geo` 9개, `elem34GeoAdv` 2개, `elem34Phy` 8개, `elem34PhyAdv` 2개
- 합계: HTML 32개
- 결과: 오류 11개, 개선 필요 14개, 양호 7개
- 기술 검사: 32개 모두 JavaScript 구문 통과, 존재하지 않는 고정 ID 참조 없음, 중복 ID 없음
- 제한: Chromium 설치가 차단된 환경이므로 실제 클릭·애니메이션·모바일 화면 재현은 하지 못했다. 아래 판정은 소스 정적 검사와 과학 내용 검토 결과다.

### 화학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_material_hardness_lab.html` | 오류 | 고무·나무·플라스틱·철에 보편적인 단일 경도와 탄성계수를 부여하고 `깊이=0.02×힘/E`를 실제 관계처럼 제시함 |
| `02_waterproof_lab.html` | 개선 필요 | 종이·천·가죽·비닐의 흡수율을 고정하고 시간에 선형 비례시킴. 재료 두께·코팅·조직에 따른 차이와 단순 모형 표시 필요 |
| `03_layered_material_lab.html` | 개선 필요 | 종이 한 장당 12g, 골판 접기 효과 4.5배를 고정함. 실험용 가상값임을 명시해야 함 |
| `04_freezing_time_lab.html` | 오류 | `1200/(0−냉동고 온도)`만으로 20mL 물의 동결 시간을 결정함. 물의 초기 온도·용기·열전달·잠열을 빠뜨린 식을 실제 시간처럼 표시함 |
| `05_evaporation_time_lab.html` | 개선 필요 | 포화수증기압은 이용하지만 공기 20°C·60%, 바람·표면적 등을 고정한 모형임을 결과 옆에 밝혀야 함 |
| `06_condensation_lab.html` | 양호 | Magnus식으로 이슬점을 구하고 컵 표면 온도와 비교하는 핵심 원리가 적절함 |
| `07_sieve_lab.html` | 양호 | 체 구멍과 알갱이 크기를 비교하는 단순 분리 원리가 활동 목적에 맞음 |
| `08_magnet_separation_lab.html` | 개선 필요 | 막대자석의 먼 거리 근사를 전체 거리에서 `1/r³`로 쓰고 클립 수까지 직접 비례시킴. 정성 모형으로 한정 필요 |
| `09_filtration_lab.html` | 개선 필요 | 소금이 여과지를 통과한다는 결론은 맞지만 `소금 알갱이가 물 입자와 거의 같은 크기` 대신 용해된 이온 설명 필요 |
| `02_umbrella_material_lab.html` | 양호 | 방수성과 무게라는 사용 목적에 따라 재료를 고르는 의사결정 구조가 적절함 |
| `07_mystery_powder_lab.html` | 양호 | 체·자석·물·거름을 순차적으로 선택하며 관찰 증거를 이용하는 구조가 적절하고 맛보기 금지 안내가 있음 |

### 지구과학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_soil_types_lab.html` | 개선 필요 | 배수 시간을 토양별 고정값으로 제시하고 밭흙을 항상 최선으로 설명함. 입도·유기물·다짐·식물별 차이를 안내해야 함 |
| `02_underground_layers_lab.html` | 오류 | 모든 땅속이 `표토→심토→모래·자갈→기반암` 순서이고 아래로 갈수록 알갱이가 굵어진다고 일반화함. 실제 토양층과 모재는 지역마다 다름 |
| `03_weathering_lab.html` | 오류 | 설탕의 질량 감소 고정식을 암석 풍화의 실제 모형처럼 쓰고, 풍화된 암석 입자만으로 흙이 된다고 정리함. 토양의 유기물·물·공기·생물 요소가 빠짐 |
| `04_strata_formation_lab.html` | 개선 필요 | 퇴적 순서를 단순히 무거운 알갱이 우선으로 설명함. 크기·밀도·모양·유속을 함께 다뤄야 하며 화석 형성 설명도 조건부로 완화 필요 |
| `05_fossils_lab.html` | 개선 필요 | 단일 화석만으로 환경을 확정하는 표현이 강함. 생물의 서식 범위, 운반·재퇴적 가능성, 여러 증거의 종합을 안내해야 함 |
| `06_reading_time_layers_lab.html` | 오류 | `화석은 생물이 죽은 그 자리에서 만들어진다`고 단정함. 유해·껍데기·흔적은 이동·재퇴적될 수 있고 지층 역전·단층도 있어 조건이 필요함 |
| `07_humidity_lab.html` | 양호 | 건구 20°C 조건의 건습구 온도차 표와 상대습도 해석이 활동 범위에서 대체로 적절함 |
| `08_wind_lab.html` | 개선 필요 | 같은 질량·같은 흡수 에너지 조건의 온도 상승비를 실제 해안의 `약 5배 더 뜨거움`으로 확대함. 온도 상승과 실제 기온을 구분해야 함 |
| `09_weather_forecast_summary_lab.html` | 개선 필요 | 습도·구름 임계값만으로 비 예보를 결정함. 교육용 규칙임을 제목과 결과에 표시하고 기압·대기 안정도·구름 발달 등 누락 변수를 안내해야 함 |
| `04_strata_order_lab.html` | 양호 | 지층 누중, 관입, 단층의 상대적 선후 관계를 구분하고 지층 역전 예외도 안내함 |
| `05_fossil_detective_lab.html` | 개선 필요 | 육상·해양 화석이 함께 나오면 단순 충돌로 처리하고 증거 개수로 결론 강도를 정함. 환경 변화·운반·재퇴적과 증거의 질을 포함해야 함 |

### 물리 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_push_pull_force.html` | 개선 필요 | 일정 시간 힘을 준 뒤 일정한 운동마찰로 멈춘다는 특수 조건에서만 거리∝힘²가 성립함. 이를 보편 법칙처럼 읽히지 않게 조건을 표시해야 함 |
| `02_force_strength_direction.html` | 오류 | kg 값을 `무게`라 부르고 `가속도=힘÷무게`로 설명함. kg은 질량이며 식은 `a=F/m`; 무게는 N 단위의 중력임 |
| `03_sound_vibration.html` | 오류 | 북 가죽의 변위 진폭을 음압 진폭과 동일시해 실제 dB 식에 직접 넣음. 두 값 사이에는 악기 구조·거리·공기 결합이 필요함 |
| `04_sound_transmission.html` | 오류 | `고체>액체>기체`를 항상 성립하는 순서로 제시하고 입자 간격만으로 속력을 설명함. 음속은 탄성률과 밀도에 함께 좌우되며 매질별 예외가 있음 |
| `05_magnet_properties.html` | 오류 | 자석 힘을 거리의 네제곱에 정확히 반비례시킴. 자석 형상과 측정 방식에 따라 달라지는 임의 모형이며 `붙는 금속은 철·니켈·코발트뿐`도 지나친 단정임 |
| `06_magnet_daily_life.html` | 개선 필요 | 나침반 N극이 `항상 북쪽`을 가리킨다고 표현함. 자기편차와 주변 자성체 영향을 고려해 `대체로 자북 방향`으로 고쳐야 함 |
| `07_weight_comparison.html` | 오류 | 일부만 비교한 뒤 `이긴 횟수`로 무게 순위를 매기므로 비교 상대와 횟수가 다르면 잘못된 순위가 나옴. 전이 관계 그래프로 판정해야 함 |
| `08_scale_balance.html` | 개선 필요 | 용수철이 100g마다 언제나 5cm 늘어난다고 설명함. Hooke 법칙은 탄성 한계 안에서만 근사적으로 성립하며 g은 질량 단위임 |
| `05_magnet_steps_lab.html` | 오류 | 종이는 영향 0, 책은 자력 범위 3칸 감소, 철판은 완전 차단으로 고정함. 비자성 물질은 주로 추가 거리 때문에 영향이 생기며 철판 효과도 형상·두께에 따라 다름 |
| `08_balance_order_lab.html` | 양호 | 양팔저울의 쌍별 비교와 전이 관계를 이용해 직접 재지 않은 순서를 추론하는 구조가 적절함 |

### 이번 묶음의 공통 수정 원칙

1. 화면의 수치가 측정 자료가 아니라 제작자가 정한 값이면 `교육용 단순 모형`이라고 결과 영역에 계속 보이게 표시한다.
2. `항상`, `실제 관계식`, `정확히`, `~뿐` 같은 표현은 성립 조건이나 예외를 함께 쓸 수 있을 때만 사용한다.
3. `질량(kg 또는 g)`과 `무게(N)`를 구분하고, 초등 수준에서는 필요하면 `저울에 나타난 질량(g)`처럼 풀어 쓴다.
4. 기본 26개 파일 다수의 range/number 입력에 `label` 또는 `aria-label`이 없다. 심화 6개 파일은 이 문제가 확인되지 않았다.
5. 실제 브라우저에서 키보드 조작, 버튼 연속 클릭, 애니메이션 종료, 360px 폭 화면, 화면낭독기 이름을 후속 확인한다.

## 4차 일괄 검증: 초등 5~6학년 8개 폴더

- 범위: `elem56Bio` 8개, `elem56BioAdv` 5개, `elem56Chem` 9개, `elem56ChemAdv` 5개, `elem56Geo` 9개, `elem56GeoAdv` 5개, `elem56Phy` 8개, `elem56PhyAdv` 5개
- 합계: HTML 54개
- 결과: 오류 24개, 개선 필요 16개, 양호 14개
- 기술 검사: 54개 모두 JavaScript 구문 통과, 존재하지 않는 고정 ID 참조 없음, 실제 마크업의 중복 ID 없음
- 접근성: 47개 파일의 range/number 입력에 연결된 `label`, `aria-label` 또는 동등한 접근성 이름이 부족함
- 제한: 실제 브라우저 실행과 모바일 렌더링은 검증 환경 제한으로 제외함

### 생물 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_plant_structure.html` | 오류 | 뿌리털 밀도·표면적·흡수량을 임의식으로 묶고 이를 `실제 공식`이라 표시함 |
| `02_flower_seed.html` | 개선 필요 | 씨앗 종말속도를 식물별 단일 실제값으로 고정함. 씨앗 형태·습도·자세에 따른 범위 안내 필요 |
| `03_digestion_circulation.html` | 오류 | ACSM 산소소비량 식에서 심박수를 임의 선형식으로 변환한 뒤 `실제 공식` 결과처럼 제시함 |
| `04_breathing_excretion.html` | 오류 | 음수도 가능한 고정 수분수지식으로 소변량을 결정하고 물 섭취와 정확히 1:1 관계라고 결론 냄 |
| `05_ecosystem.html` | 개선 필요 | 포식자 수만으로 먹이 생물의 평형 개체수를 정하는 단순 모형임을 명시해야 함 |
| `06_environment_organism.html` | 개선 필요 | 빛과 식물 키·잎 넓이를 고정 직선식으로 제시하고 서로 다른 여우 종의 귀 차이를 온도 하나로 설명함 |
| `07_fungi_microbes.html` | 오류 | Q10=2를 모든 미생물의 법칙으로 적용해 온도가 계속 높을수록 성장하게 함. 최적 온도와 고온 억제가 빠짐 |
| `08_biodiversity_life.html` | 개선 필요 | 생체모방 성능 수치를 `모두 실제 자료`라고 단정함. 제품·시험 조건과 출처를 붙이거나 모형값으로 표시해야 함 |
| `01_transpiration_lab.html` | 오류 | 잎 수×시간당 증산량을 고정하고 봉지를 씌우면 증산량을 0으로 계산함. 봉지는 수증기를 모으는 장치이지 증산을 완전히 멈추지 않음 |
| `03_heartbeat_blood_lab.html` | 오류 | 1회 박출량을 운동 중에도 70mL로 고정해 박동수 2배→혈액량 정확히 2배라고 결론 냄 |
| `04_breathing_oxygen_lab.html` | 오류 | 일회호흡량과 들숨·날숨 산소 농도를 활동과 무관하게 고정해 산소 섭취량이 호흡수에 정확히 비례한다고 함 |
| `05_energy_pyramid_lab.html` | 오류 | 10% 법칙을 매 단계 정확한 값으로 쓰고 먹이 단계가 오르면 땅·물이 항상 10배 든다고 일반화함 |
| `07_microbe_growth_lab.html` | 오류 | 모든 세균이 실온 60분·30°C 30분마다 분열한다고 고정하며 `2시간은 아직 안전`이라고 안내함. 식품 안전상 부적절함 |

### 화학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_dissolving_sugar_lab.html` | 개선 필요 | `주스가루`를 항상 완전한 용액으로 분류함. 제품에 따라 불용성 성분이 있을 수 있어 시료 조건 필요 |
| `02_saturation_lab.html` | 오류 | 설탕 용해도를 `100+1.2×온도`로 두고 정비례라 표시함. 실제 용해도 곡선·수치와 맞지 않음 |
| `03_evaporation_separation_lab.html` | 오류 | 10% 소금물의 부피(mL)를 그대로 질량(g)으로 보고 소금 질량을 계산함. 농도 기준과 밀도를 구분해야 함 |
| `04_acid_detective_lab.html` | 개선 필요 | 산성 물질을 모두 신맛으로 정리함. 맛보기 금지와 `일부 식품 산성 용액`이라는 한정이 필요함 |
| `05_base_detective_lab.html` | 오류 | 표백제·유리세정제를 안전한 일반 지시약 시료처럼 다룸. 조성 차이와 표백제의 산화·탈색 효과, 보호구 안내가 빠짐 |
| `06_neutralization_lab.html` | 오류 | 산과 염기의 부피만 같으면 중성이라고 처리함. 농도·산염기 종류·반응비가 같다는 조건이 필요함 |
| `07_oxygen_carbon_dioxide_lab.html` | 양호 | 산소·이산화 탄소·질소·공기의 연소 및 석회수 반응 비교가 활동 범위에서 적절함 |
| `08_nitrogen_hydrogen_lab.html` | 개선 필요 | 부력에서 풍선 막 무게를 2g으로 고정함. 풍선 크기·재질에 따라 상승 여부가 달라짐을 표시해야 함 |
| `09_gas_pressure_volume_summary_lab.html` | 오류 | 누르는 힘을 곧 압력으로 취급하고 온도·기체량 조건 없이 힘×부피가 일정하다고 함 |
| `02_solubility_temp_lab.html` | 양호 | 질산칼륨의 온도별 용해도 자료와 냉각 석출 계산이 대체로 적절함 |
| `03_evaporation_salt_lab.html` | 오류 | 부피 백분율처럼 입력하면서 소금 질량과 물 질량을 직접 계산함. 질량%, 질량/부피% 중 기준을 명시해야 함 |
| `06_neutral_point_lab.html` | 개선 필요 | 산의 `진하기 n배`만큼 같은 부피의 염기가 필요하다는 결과는 같은 반응 당량의 산·염기라는 조건에서만 성립함 |
| `07_gas_weight_lab.html` | 개선 필요 | 같은 부피 기체의 질량 비교는 적절하지만 실제 풍선 상승은 막 무게·온도·압력까지 포함해야 함 |
| `09_pressure_volume_lab.html` | 오류 | Boyle 법칙의 압력을 `누르는 힘`으로 바꾸고 일정 온도 조건을 빠뜨림. 잠수부는 상승 중 숨을 참지 않고 정상적으로 호흡해야 함 |

### 지구과학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_solar_system_family.html` | 오류 | 지구와 행성의 궤도 반지름 차이÷16km/s를 실제 탐사선 도착 시간으로 계산함. 행성 위치·전이궤도·가감속을 무시함 |
| `02_planet_size_type.html` | 양호 | 동일 배율의 행성 지름 비교와 지구형·목성형 분류가 대체로 적절함 |
| `03_star_vs_planet.html` | 양호 | 별의 자체 발광과 행성의 반사, 북두칠성으로 북극성 찾기 활동이 적절함 |
| `04_earth_tilt_season.html` | 양호 | 23.5° 자전축 기울기와 양반구 계절 관계가 활동 수준에서 적절함 |
| `05_sun_altitude_shadow.html` | 양호 | 수평면의 수직 막대에 대한 `그림자=높이/tan(고도)` 관계가 적절함 |
| `06_day_night_length.html` | 개선 필요 | 근사 천문식을 `실제 공식`이라고 표현함. 태양 원반·대기 굴절·일출 정의에 따른 차이를 안내해야 함 |
| `07_air_mass_journey.html` | 개선 필요 | 계절마다 한 기단이 지배한다고 고정하고 바다=다습·대륙=건조로 단정함. 변질·이동 경로·혼합 가능성 보완 필요 |
| `08_front_wind.html` | 개선 필요 | 전선 경사·강수폭·지속시간을 고정값으로 제시하고 비열비를 실제 육지·바다 온도 변화비로 확대함 |
| `09_forecast_daily_life.html` | 오류 | `강수확률 60% 이상이면 우산`과 기온별 옷차림을 기상청의 공식 기준처럼 표시함. 생활 선택 기준이지 보편 예보 기준이 아님 |
| `01_solar_system_scale_lab.html` | 양호 | 천체 크기와 거리의 동일 축척 계산이 적절함 |
| `03_lightyear_distance_lab.html` | 양호 | 빛의 속력과 이동 시간으로 거리·광년을 계산하는 구조가 적절함 |
| `05_shadow_altitude_lab.html` | 양호 | 막대와 그림자로 태양 고도를 역산하는 기하 관계가 적절함 |
| `06_daylength_lab.html` | 오류 | 월별 값을 `실제로 잰` 자료라 하면서 일출·일몰을 매일 12시 중심으로 배치함. 경도·균시차·굴절을 반영하지 않음 |
| `09_windchill_lab.html` | 오류 | 체감온도 공식의 적용 범위를 표시하지 않고 풍속 0m/s에도 사용함. 해당 공식은 낮은 기온과 일정 이상 풍속에서만 유효함 |

### 물리 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_hot_cold_water_lab.html` | 개선 필요 | 같은 물질·단열·열손실 없음이라는 조건에서만 가중평균과 열량 보존이 정확히 성립함 |
| `02_metal_conduction_lab.html` | 오류 | 열확산식에 임의 도달 기준을 생략한 채 `열이 거리 x까지 가는 시간=x²/(4α)`와 녹는 시간을 실제값처럼 제시함 |
| `03_convex_lens_focus_lab.html` | 양호 | 얇은렌즈 근사에서 상 위치·배율·실상/허상 분류가 적절함 |
| `04_concave_convex_lab.html` | 개선 필요 | 볼록거울과 오목렌즈를 `같은 원리`라 표현함. 둘 다 빛을 퍼뜨리지만 반사와 굴절이라는 차이를 밝혀야 함 |
| `05_battery_brightness_lab.html` | 오류 | 전구 저항을 항상 5Ω으로 고정해 전지 수 2배→밝기 4배라고 함. 실제 필라멘트 저항·전지 내부저항은 변함 |
| `06_series_parallel_lab.html` | 양호 | 이상적인 동일 전구와 일정 전압원 조건의 직렬·병렬 비교가 적절함 |
| `07_speed_race_lab.html` | 양호 | 일정한 평균 속력에서 거리·시간 관계와 속력 계산이 적절함 |
| `08_car_distance_lab.html` | 양호 | 일정한 평균 속력 조건에서 거리·속력·시간의 관계가 적절함 |
| `01_target_temperature_lab.html` | 개선 필요 | 같은 비열의 물, 단열, 용기 열용량 무시 조건을 명시하면 현재 혼합 계산을 유지할 수 있음 |
| `02_thermos_design_lab.html` | 개선 필요 | 선형 냉각 모형임을 안내하지만 4시간까지 같은 °C/분을 적용한 결과는 실제 보온 성능으로 읽히지 않게 분리해야 함 |
| `03_magnifier_burn_lab.html` | 오류 | 이상적 광학 집광비에서 종이 연소 시간을 임의 역비례식으로 계산함. 날씨·렌즈 투과율·초점·종이 상태가 빠짐 |
| `04_flashlight_design_lab.html` | 오류 | 직렬 n개 밝기 n²·시간 60/n, 병렬 시간 60n을 보편 법칙처럼 제시함. 전구/LED 회로와 전지 특성에 따라 달라짐 |
| `05_stopping_distance_lab.html` | 양호 | 반응거리와 일정 감속 제동거리 모형을 구분하고 실제 도로의 누락 변수를 명시함 |

### 이번 묶음의 우선 수정 순서

1. 안전 문구: `07_microbe_growth_lab.html`의 `2시간은 아직 안전`, 표백제 실험, 돋보기 연소 활동을 먼저 수정한다.
2. `실제 공식·실제 측정값` 표시: 출처와 조건이 없는 임의식은 `교육용 단순 모형`으로 바꾼다.
3. 단위·농도: mL를 g으로 바로 바꾸는 소금물 계산과 힘/압력 혼용을 바로잡는다.
4. 생리 수치: 심박출량·호흡량·소변량을 개인과 활동에 무관한 정확한 선형식으로 제시하지 않는다.
5. 모든 range/number 입력에 화면 라벨과 연결된 `label for`, `aria-label` 또는 `aria-labelledby`를 추가한다.

## 5차 일괄 검증: 중학교 1학년 3개 폴더

- `milddle1BioGeo`: 10개
- `milddle1Chem`: 10개
- `milddle1Phy`: 11개
- 별도 `Adv` 폴더는 없었으며, 현재 보이는 중학교 1학년 폴더 3개를 모두 검사했다.
- 이번 묶음 판정: 오류 10개, 개선 필요 12개, 양호 9개

### 기술 검사 결과

- 31개 파일의 인라인 JavaScript가 모두 구문 검사를 통과했다.
- `milddle1Chem/10_gas_properties_summary_lab.html`은 존재하지 않는 `zlNudge`, `zlNudgeGo`, `zlNudgeLater`에 `addEventListener`를 연결한다. 현재 코드대로면 페이지 초기화 중 `null` 참조 오류가 발생할 수 있다.
- `milddle1Chem/02_state_change_types_lab.html`, `08_charles_law_lab.html`, `09_gas_diffusion_lab.html`에 위 세 ID가 중복된다. 뒤의 두 파일은 관련 마크업과 스크립트 블록도 중복되어 이벤트 동작이 불안정할 수 있다.
- 31개 중 26개는 range·number·select 입력 중 하나 이상에 연결된 `label`, `aria-label` 또는 `aria-labelledby`가 없다.
- 실제 브라우저 렌더링·터치 조작 검사는 검증 환경의 Chromium 설치 제한 때문에 수행하지 못했다. 이번 결과는 정적 코드 검사와 과학 내용 검토 기준이다.

### 생물·지구과학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_stimulus_response_lab.html` | 개선 필요 | 거리÷신경 전달 속도 계산은 타당하나 속도는 신경 섬유 종류·굵기·온도 등에 따라 달라지는 대표값임을 표시해야 함 |
| `02_diffusion_lab.html` | 양호 | Stokes–Einstein 식과 1차원 확산의 `t=L²/(2D)`를 가정과 함께 사용해 활동 범위에서 적절함 |
| `03_scale_observation_lab.html` | 개선 필요 | 세포·조직·기관·기관계·개체를 고정 크기 단계처럼 배열함. 생물학적 구성 단계와 대표 크기 비교를 구분해야 함 |
| `04_classification_lab.html` | 오류 | 임의의 예/아니요 기준 추가와 계·문·강·목·과·속·종의 원리를 동일시함. 현대 분류는 진화적 유연관계가 핵심임 |
| `05_habitat_extinction_lab.html` | 개선 필요 | 종–면적 관계 `S=cA^z`와 개체수∝면적을 고정 법칙처럼 사용함. 경험 모형의 조건과 한계를 밝혀야 함 |
| `06_orbit_lab.html` | 양호 | 태양 질량 기준 AU·년 단위의 케플러 제3법칙 `T=a^(3/2)` 적용이 적절함 |
| `07_blackbody_lab.html` | 개선 필요 | 빈의 변위 법칙은 맞지만 RGB 표시를 별의 실제 보이는 색으로 단정하기 어렵고 불꽃색은 화학 조성의 영향도 받음 |
| `08_exoplanet_density_lab.html` | 개선 필요 | 제목은 외계행성이지만 태양계 행성을 사용하며, 2.7 AU 서리선 하나로 밀도 차이를 직접 설명해 형성 과정을 과도하게 단순화함 |
| `09_planet_survey_lab.html` | 개선 필요 | `2024` 위성 수가 현재 값과 다름. NASA 2026년 자료는 목성 115개·토성 293개·천왕성 29개이며 해왕성은 16개임. 기준일과 출처를 함께 갱신해야 함 |
| `10_solar_system_exploration_lab.html` | 양호 | 태양 중력의 2체 근사에서 지구 궤도 거리의 탈출 속력 약 42.1 km/s 계산이 적절함 |

위성 수 확인 출처: [NASA Jupiter Moons](https://science.nasa.gov/jupiter/jupiter-moons/), [NASA Saturn Moons](https://science.nasa.gov/saturn/moons/), [NASA Uranus Moons](https://science.nasa.gov/uranus/moons/), [NASA Neptune Moons](https://science.nasa.gov/neptune/moons/) (2026-09-12 확인).

### 화학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_states_of_matter_lab.html` | 오류 | 기체 질소의 rms 속도식을 고체·액체·기체 모두의 입자 운동 속도로 사용해 응집상 입자 운동을 잘못 표현함 |
| `02_state_change_types_lab.html` | 오류 | 대화상자 ID 3개가 중복됨. 드라이아이스에 녹는점·끓는점을 모두 −78.5°C로 넣은 구성도 승화 조건과 맞게 분리해야 함 |
| `03_heat_absorption_release_lab.html` | 개선 필요 | 비열·융해열·기화열 계산은 타당하나 일정 압력, 열손실 없음, 용기 열용량 무시라는 이상 조건을 결과에 명시해야 함 |
| `04_heating_curve_lab.html` | 개선 필요 | 모든 물질에 같은 임의 구간 길이와 시간을 써서 실제 가열 곡선처럼 보임. 정성 모형과 실제 물성 계산을 구분해야 함 |
| `05_phase_change_applications_lab.html` | 오류 | 냉매 적합성을 끓는점과 잠열만으로 결정함. 운전 압력·안전성·환경성·재료 호환성 등 필수 조건이 빠짐 |
| `06_gas_particles_pressure_lab.html` | 오류 | 여러 변수를 동시에 바꾼 자료에 단순 공분산을 적용해 비례 관계를 판정하므로 교란된 결론이 나올 수 있음 |
| `07_boyles_law_lab.html` | 양호 | 기체량과 온도가 일정한 조건을 밝히고 압력–부피 반비례를 적절히 계산함 |
| `08_charles_law_lab.html` | 오류 | 중복 ID·스크립트가 있으며 이상 기체 직선을 −273°C까지 외삽해 모든 실제 기체에 그대로 성립하는 것처럼 설명함 |
| `09_gas_diffusion_lab.html` | 오류 | 중복 ID·스크립트가 있고 혼합 시간을 분자 평균 속력의 역수로 둠. 기체 확산계수의 온도·압력 의존성과 맞지 않음 |
| `10_gas_properties_summary_lab.html` | 오류 | 없는 대화상자 요소 3개에 이벤트를 연결해 초기화 중 실행 오류가 발생할 수 있음 |

### 물리 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `01_temperature_lab.html` | 양호 | 이상 기체 질소의 rms 속력 계산과 온도에 따른 경향이 적절함 |
| `02_heat_transfer_lab.html` | 오류 | 열 도달 기준과 경계 조건 없이 `0.35L²/α`를 실제 도달 시간으로 제시함. 열확산에는 단일 도착 시각이 없음 |
| `03_thermal_equilibrium_lab.html` | 개선 필요 | 질량 가중 평균은 두 물체의 비열이 같고 단열·용기 열용량 무시 조건일 때만 성립함 |
| `04_specific_heat_thermal_expansion_lab.html` | 개선 필요 | 대표 비열·팽창계수 계산은 가능하나 기름·모래 값의 변동성과 큰 온도 구간에서 계수 변화 안내가 필요함 |
| `05_insulation_lab.html` | 오류 | 진공을 고유 열전도율 `0.005 W/(m·K)`인 재료처럼 취급함. 진공층에서는 복사와 지지부 열교가 핵심임 |
| `06_force_representation_lab.html` | 양호 | 두 힘의 합력 크기와 방향을 벡터 성분·코사인 관계로 적절히 계산함 |
| `07_gravity_weight_lab.html` | 양호 | 천체별 중력가속도와 `W=mg`의 질량·무게 구분이 적절함 |
| `08_elasticity_friction_lab.html` | 개선 필요 | Hooke 법칙의 탄성 한계와 정지·운동 마찰의 차이, 마찰계수가 조건에 따라 달라짐을 밝혀야 함 |
| `09_buoyancy_lab.html` | 양호 | 균질 물체가 자유롭게 뜨는 이상 조건에서 잠긴 부피 비와 밀도 관계가 적절함 |
| `10_pressure_lab.html` | 양호 | `P=F/A`와 정수압 `P=P₀+ρgh` 계산이 활동 범위에서 적절함 |
| `11_wall_insulation_lab.html` | 개선 필요 | 교육용 모형임은 표시했지만 재료별 냉각 상수를 실제 벽체 성능과 연결하려면 두께·면적·열저항 조건이 필요함 |

### 이번 묶음의 우선 수정 순서

1. `10_gas_properties_summary_lab.html`의 없는 요소 참조를 제거하거나 실제 대화상자 마크업을 복원한다.
2. `02_state_change_types`, `08_charles_law`, `09_gas_diffusion`의 중복 ID와 중복 스크립트를 하나로 정리한다.
3. 기체 rms 속도를 응집상에 적용한 `01_states_of_matter`와 확산 시간을 평균 속력으로 계산한 `09_gas_diffusion`의 과학 모형을 교체한다.
4. `09_planet_survey`의 위성 수에 기준일·출처를 표시하고 최신 공식 자료로 갱신한다.
5. 26개 파일의 입력 요소에 연결된 접근성 이름을 추가하고 모바일 브라우저에서 터치·대화상자·캔버스를 후속 검사한다.

## 6차 일괄 검증: 중학교 2학년 8개 폴더

- 기본: `milddle2Bio`, `milddle2Chem`, `milddle2Geo`, `milddle2Phy` 각 10개
- 심화: `milddle2BioAdv`, `milddle2ChemAdv`, `milddle2GeoAdv`, `milddle2PhyAdv` 각 5개
- 합계 60개
- 이번 묶음 판정: 오류 13개, 개선 필요 29개, 양호 18개

### 기술 검사 결과

- 60개 파일의 인라인 JavaScript가 모두 구문 검사를 통과했다.
- 중복 ID와 무방비 상태의 존재하지 않는 DOM 요소 참조는 확인되지 않았다.
- `milddle2BioAdv/06_enzyme_temperature_lab.html`의 `resetPointsX` 참조는 대상이 없지만 `&&` 단락 평가로 보호되어 실행 오류를 일으키지는 않는다. 불필요한 코드는 삭제 권장이다.
- 60개 중 58개는 range·number·select 입력 중 하나 이상에 연결된 `label`, `aria-label` 또는 `aria-labelledby`가 없다.
- 실제 브라우저 렌더링·터치 조작 검사는 검증 환경의 Chromium 설치 제한 때문에 수행하지 못했다. 이번 결과는 정적 코드 검사와 과학 내용 검토 기준이다.

### 생물 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `milddle2Bio/01_photosynthesis_lab.html` | 개선 필요 | 빛에 따른 기포 수를 임의 포화식으로 생성함. 식물·온도·CO₂ 조건과 교육용 모형임을 표시해야 함 |
| `milddle2Bio/02_plant_tissue_lab.html` | 개선 필요 | 조직별 세포 분열 활성도 92·6·16·9%가 출처 없는 모형값이며 형성층 등 분열조직의 다양성을 반영하지 않음 |
| `milddle2Bio/03_water_transport_lab.html` | 오류 | 잎 수가 늘면 물관 이동 속도가 정확히 `0.15×잎 수`로 증가한다고 제시함. 증산은 잎 면적·기공·습도·빛·바람 등에 좌우됨 |
| `milddle2Bio/04_transpiration_lab.html` | 개선 필요 | 바람과 증산량을 고정 직선식으로 처리함. 강풍에서 기공 반응과 온도·습도 조건을 포함해야 함 |
| `milddle2Bio/05_photosynthesis_use_lab.html` | 오류 | 광합성량과 호흡량을 고정 직선식으로 만들고 낙엽의 주원인을 짧은 낮과 잎의 호흡·증산 감소로 단순화함 |
| `milddle2Bio/06_digestion_lab.html` | 개선 필요 | 모든 소화 효소가 37℃에서 같은 종 모양 활성 곡선을 갖는 것처럼 제시함. 효소별 최적 pH·온도 차이가 필요함 |
| `milddle2Bio/07_circulation_lab.html` | 개선 필요 | 운동 강도와 심박수를 `70+0.6×강도`로 고정함. 개인·연령·훈련도와 비선형 반응을 안내해야 함 |
| `milddle2Bio/08_respiration_lab.html` | 개선 필요 | 폐포 수만으로 산소 흡수량이 정확히 정비례한다고 함. 환기·관류·농도차·막 두께도 제한 요인임 |
| `milddle2Bio/09_excretion_lab.html` | 오류 | 물 섭취 증가분이 거의 그대로 오줌이 되고 `섭취량−오줌량≈50mL`로 일정하다고 함. 시간·ADH·발한·음식 수분 변화를 무시함 |
| `milddle2Bio/10_integration_lab.html` | 개선 필요 | 운동 강도와 산소 요구량을 고정 직선식으로 두고 배설계가 운동 시 노폐물을 더 많이 거른다고 단순화함 |
| `milddle2BioAdv/01_light_limiting_factor_lab.html` | 개선 필요 | 점광원의 역제곱 법칙과 임의 Michaelis형 반응식을 실제 전등·검정말 실험에 그대로 적용함 |
| `milddle2BioAdv/04_transpiration_vaseline_lab.html` | 오류 | 바세린 처리량을 고정 수치로 만들고 한여름 대낮의 물주기가 비효율적인 이유를 `뿌리 흡수 전 증산`으로 잘못 설명함 |
| `milddle2BioAdv/06_enzyme_temperature_lab.html` | 개선 필요 | 정성적 경향은 맞지만 아밀레이스 활성·변성 시간을 임의 함수로 실제 실험 시간처럼 표시함 |
| `milddle2BioAdv/07_pulse_recovery_lab.html` | 개선 필요 | 대상별 안정·최대 맥박과 회복을 고정 직선·지수함수로 생성함. 측정값이 아닌 모형임을 밝혀야 함 |
| `milddle2BioAdv/09_reabsorption_lab.html` | 양호 | 원뇨 180L·오줌 1.5L에서 재흡수량 178.5L와 재흡수율 약 99.2% 계산이 활동 범위에서 적절함 |

### 화학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `milddle2Chem/01_pure_substance_mixture_lab.html` | 오류 | 소금이 물 표면을 막아 끓는점이 오른다고 설명함. 끓는점 오름은 용액의 증기압 저하로 설명해야 함 |
| `milddle2Chem/02_density_lab.html` | 양호 | 동일 물질에서 질량=밀도×부피와 밀도 불변 관계가 적절함 |
| `milddle2Chem/03_solubility_melting_boiling_lab.html` | 개선 필요 | 자당 용해도 자료는 적절하나 고농도 소금물에 이상용액 어는점 내림식을 `실제값`처럼 적용함 |
| `milddle2Chem/04_separation_density_distillation_lab.html` | 오류 | 에탄올–물 증류에서 78.4℃ 에탄올이 완전히 나온 뒤 100℃ 물만 나온다고 표현함. 증기에도 두 성분이 함께 존재함 |
| `milddle2Chem/05_recrystallization_chromatography_lab.html` | 개선 필요 | 재결정 계산은 적절하나 Rf 대표값에 전개액·종이·시료 조건이 없어 실제값으로 재현하기 어려움 |
| `milddle2Chem/06_elements_atoms_lab.html` | 양호 | 1~20번 원소 범위의 양성자·전자·대표 동위원소 및 전자 배치가 활동 범위에서 적절함 |
| `milddle2Chem/07_molecules_lab.html` | 양호 | 분자식 원자 수와 주요 분자의 결합각·형태 설명이 대체로 적절함 |
| `milddle2Chem/08_ions_lab.html` | 양호 | 전자 이동과 `전하=양성자 수−전자 수` 관계가 적절함 |
| `milddle2Chem/09_precipitation_reaction_lab.html` | 양호 | 제시된 주요 앙금 생성 조합과 색이 활동 범위에서 적절함 |
| `milddle2Chem/10_matter_composition_summary_lab.html` | 개선 필요 | `원자→분자·이온→화합물`을 단일 계층처럼 제시함. 홑원소 분자와 분자 화합물·이온 화합물을 분리해야 함 |
| `milddle2ChemAdv/02_density_float_lab.html` | 양호 | 균질 물체와 물의 밀도 비교라는 활동 조건에서 뜨고 가라앉는 판정이 적절함 |
| `milddle2ChemAdv/03_solubility_precipitation_lab.html` | 양호 | 물의 양과 온도별 용해도 차이로 석출량을 계산하는 구조가 적절함 |
| `milddle2ChemAdv/06_atomic_number_lab.html` | 오류 | 모든 1~20번 원자에 전자 ±2를 허용해 H가 전자 2개를 잃는 등 불가능한 상태와 비대표 이온을 만들 수 있음 |
| `milddle2ChemAdv/07_molecule_count_lab.html` | 개선 필요 | 계수·아래첨자 계산은 맞지만 `H₄O₂라는 물질은 존재하지 않는다`는 단정 대신 최소 정수비와 실제 화학종을 구분해야 함 |
| `milddle2ChemAdv/08_ion_formula_lab.html` | 양호 | 전하 합의 중성과 최소 정수비로 이온 화합물 화학식을 만드는 과정이 적절함 |

### 지구과학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `milddle2Geo/01_earth_internal_structure.html` | 개선 필요 | PREM 경향은 반영했지만 선형 보간값을 실제 속도처럼 표시하고 판 운동의 원동력을 맨틀 대류 하나로 단정함 |
| `milddle2Geo/02_plate_tectonics.html` | 개선 필요 | 해령 확장 속도를 장기간 일정값으로 적용함. 실제 속도의 시공간 변화와 반확장률·전확장률 구분을 더 명확히 해야 함 |
| `milddle2Geo/03_earthquake_volcano.html` | 오류 | P·S 속도를 모든 경로에서 8·4km/s로 고정하고 화산 형태·경사를 SiO₂ 함량만으로 결정해 실제 결과처럼 제시함 |
| `milddle2Geo/04_rock_cycle.html` | 오류 | 시작 암석과 압력을 사실상 무시하고 온도만으로 모든 암석을 점판암→편암→편마암으로 바꿈. 사암·화강암의 변성 경로와 맞지 않음 |
| `milddle2Geo/05_weathering_soil.html` | 오류 | 동결융해 질량 손실을 공극률만의 고정 지수식으로 생성하고 출처 없는 수치를 실제 반복 결과처럼 제시함 |
| `milddle2Geo/06_star_brightness_color.html` | 양호 | 거리 제곱 반비례, 등급–광도 관계, 빈의 변위 법칙을 일관되게 적용함 |
| `milddle2Geo/07_star_motion.html` | 오류 | 북극성이 `어디서 봐도 같은 방향`이라고 표현함. 고도는 관측 위도에 따라 달라지고 남반구 대부분에서는 보이지 않음 |
| `milddle2Geo/08_galaxy.html` | 개선 필요 | 별 개수를 `1/sin(은위)`로만 정해 원반의 유한한 반지름·중심 방향·성간 소광을 무시함 |
| `milddle2Geo/09_universe_expansion.html` | 개선 필요 | 저적색편이 근사식을 넓은 거리까지 사용하고 `1/H₀`을 우주 나이와 동일시함. 적용 범위와 우주론 모형 조건이 필요함 |
| `milddle2Geo/10_space_exploration.html` | 개선 필요 | 2체 근사 계산은 맞지만 지표 발사에서 대기·지구 자전·추력 과정을 무시한 이상 모형임을 결과에 표시해야 함 |
| `milddle2GeoAdv/02_plate_speed_lab.html` | 양호 | 일정 속력 가정과 실제 판 속도 변화 가능성을 함께 밝히며 거리=속력×시간 계산이 적절함 |
| `milddle2GeoAdv/03_earthquake_energy_lab.html` | 개선 필요 | 규모 1당 약 31.6배는 적절하나 진도를 거리 하나의 임의식으로 정하고 규모가 어디서 재도 완전히 같다고 단순화함 |
| `milddle2GeoAdv/06_star_magnitude_lab.html` | 양호 | 포그슨 등급계의 5등급=100배와 겉보기·절대등급 구분이 적절함 |
| `milddle2GeoAdv/07_diurnal_annual_motion_lab.html` | 개선 필요 | 별의 일주 운동을 정확히 24시간·15°/시간, 연주 운동을 정확히 30°/월로 제시함. 항성일과 월 길이에 따른 근사임을 밝혀야 함 |
| `milddle2GeoAdv/09_hubble_law_lab.html` | 개선 필요 | H₀=70을 고정하고 적색편이만으로 거리를 직접 확정함. 가까운 은하의 고유운동과 거리사다리·H₀ 불확실성을 안내해야 함 |

### 물리 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `milddle2Phy/01_light_straight_line_lab.html` | 오류 | 공식은 `그림자=20×(50+d)/50`인데 절편 20인 관계를 거리와의 정비례라고 결론 냄 |
| `milddle2Phy/02_light_reflection_lab.html` | 양호 | 반사 법칙과 근축 구면거울 식에 따른 상 분류가 적절함 |
| `milddle2Phy/03_refraction_lens_lab.html` | 양호 | 스넬 법칙과 얇은렌즈 근사에 따른 상 분류가 적절함 |
| `milddle2Phy/04_wave_properties_lab.html` | 양호 | `T=1/f`와 횡파·종파의 기본 성질이 적절함 |
| `milddle2Phy/05_sound_lab.html` | 양호 | 공기 중 음속을 고정한 조건에서 `v=fλ` 계산과 초음파 파장 예측이 적절함 |
| `milddle2Phy/06_static_electricity_lab.html` | 개선 필요 | 쿨롱 법칙의 거리 제곱 반비례는 맞지만 전하량·매질·단위를 숨긴 임의 상수를 실제 힘처럼 보이게 함 |
| `milddle2Phy/07_ohms_law_lab.html` | 개선 필요 | 20V까지 니크롬선 저항을 일정하게 둠. 큰 전류의 온도 상승과 저항 변화, 전지 내부저항 조건이 필요함 |
| `milddle2Phy/08_electromagnetism_lab.html` | 개선 필요 | 도선 자기장 계산은 타당하나 지구 자기장과 클립 수를 고정 대표값으로 쓰므로 실험 조건과 모형값 표시가 필요함 |
| `milddle2Phy/09_electromagnetic_induction_lab.html` | 양호 | 자기선속 변화율과 속도에 따른 유도전류의 방향·상대 세기를 정성적으로 적절히 구현함 |
| `milddle2Phy/10_electricity_magnetism_summary_lab.html` | 개선 필요 | `정전기에서 전하가 이동하면 전류`라는 연결은 지속 전류의 회로·전위차 조건을 보완해야 함 |
| `milddle2PhyAdv/03_lens_image_cases_lab.html` | 양호 | 얇은렌즈 근사에서 볼록·오목렌즈의 상 위치·방향·배율 분류가 적절함 |
| `milddle2PhyAdv/04_wave_speed_lab.html` | 개선 필요 | `v=fλ`는 맞지만 공기 중 음속 340m/s가 온도에 따른 대표값임을 표시해야 함 |
| `milddle2PhyAdv/07_series_parallel_lab.html` | 개선 필요 | 이상 저항 계산은 맞지만 실제 전구 밝기를 고정 저항의 `I²R`만으로 판단함. 필라멘트 온도와 정격 조건이 필요함 |
| `milddle2PhyAdv/08_electromagnet_strength_lab.html` | 오류 | 전류·감은 수를 두 배로 하면 클립 수가 정확히 네 배, 철심은 정확히 다섯 배라고 고정함. 포화·형상·간격을 무시한 임의식임 |
| `milddle2PhyAdv/09_induction_direction_lab.html` | 개선 필요 | 렌츠 법칙은 맞지만 최대 유도전류를 속력×감은 수에 정확히 비례시킴. 코일 저항과 자석·기하 조건을 명시해야 함 |

### 이번 묶음의 우선 수정 순서

1. `milddle2Phy/01_light_straight_line_lab.html`의 `정비례`를 `절편이 있는 선형 관계`로 고친다.
2. `milddle2Chem/01_pure_substance_mixture_lab.html`의 끓는점 오름 원인을 증기압 저하로 교체하고, `04_separation_density_distillation_lab.html`의 에탄올–물 완전 분리 표현을 수정한다.
3. `milddle2Geo/04_rock_cycle.html`에서 시작 암석·압력·유체 조건에 맞는 변성 경로를 사용한다.
4. `milddle2ChemAdv/06_atomic_number_lab.html`에서 원소별 허용 가능한 전자 수와 대표 이온만 선택 가능하게 제한한다.
5. `milddle2Bio/03_water_transport_lab.html`, `09_excretion_lab.html`, `milddle2PhyAdv/08_electromagnet_strength_lab.html`의 고정 직선식을 교육용 모형으로 명시하거나 실제 자료 기반 범위로 교체한다.
6. 58개 파일의 입력 요소에 접근성 이름을 추가하고 모바일 브라우저에서 터치·대화상자·캔버스를 후속 검사한다.

## 7차 일괄 검증: 중학교 3학년 8개 폴더

- 기본: `milddle3Bio`, `milddle3Chem`, `milddle3Geo`, `milddle3Phy` 각 10개
- 심화: `milddle3BioAdv` 3개, `milddle3ChemAdv` 3개, `milddle3GeoAdv` 4개, `milddle3PhyAdv` 1개
- 합계 51개
- 이번 묶음 판정: 오류 14개, 개선 필요 18개, 양호 19개

### 기술 검사 결과

- 51개 파일의 인라인 JavaScript가 모두 구문 검사를 통과했다.
- 중복 ID와 존재하지 않는 고정 DOM 요소 참조는 확인되지 않았다.
- 51개 모두 반응형 미디어 쿼리가 있으며 외부 스크립트 의존성은 없다. Google Fonts는 51개 모두 외부 연결에 의존한다.
- 51개 중 48개는 range·number·select 입력 중 하나 이상에 연결된 `label`, `aria-label` 또는 `aria-labelledby`가 없다.
- 실제 브라우저 렌더링·터치 조작 검사는 검증 환경의 Chromium 설치 제한 때문에 수행하지 못했다. 이번 결과는 정적 코드 검사와 과학 내용 검토 기준이다.

### 생물 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `milddle3Bio/01_sensory_organs_lab.html` | 개선 필요 | Moon–Spencer 식을 단일 개인의 실제 반응처럼 사용함. 개인차·적응 상태·측정 조건과 대표 모형임을 밝혀야 함 |
| `milddle3Bio/02_hearing_smell_taste_lab.html` | 개선 필요 | 미각 역치와 연령별 최고 가청 주파수를 고정 대표값으로 제시함. 개인차와 검사 조건, 산 용액 직접 시험 금지를 안내해야 함 |
| `milddle3Bio/03_neuron_pathway_lab.html` | 개선 필요 | 말이집 유무에 따라 전도 속도를 정확히 60·1m/s로 고정함. 축삭 지름·온도·신경 종류에 따른 범위가 필요함 |
| `milddle3Bio/04_reflex_conscious_response_lab.html` | 개선 필요 | 무릎반사·회피반사·의식 반응 시간을 고정하고 반사 경로를 단순화함. 개인차와 회피반사의 뇌 전달도 함께 설명해야 함 |
| `milddle3Bio/05_hormones_lab.html` | 오류 | 일반 식후 혈당을 75g 경구당부하검사의 2시간 진단 기준과 동일시하고 단일 결과로 당뇨병을 진단함 |
| `milddle3Bio/06_mitosis_lab.html` | 개선 필요 | 모든 세포가 매 회 동기적으로 분열한다는 조건 없이 `한 세포가 10번 분열하면 2¹⁰개`라고 표현함 |
| `milddle3Bio/07_meiosis_lab.html` | 양호 | 선택한 이배체 생물의 체세포·생식세포 염색체 수와 감수분열 두 단계 설명이 적절함 |
| `milddle3Bio/08_embryonic_development_lab.html` | 개선 필요 | 사람 초기 배아의 일자별 세포 수와 지름을 고정한 `실제 일정`으로 제시함. 발생 속도·배아 크기의 범위를 안내해야 함 |
| `milddle3Bio/09_mendel_law_lab.html` | 양호 | Yy 교배의 무작위 표본과 큰 표본에서 이론비에 가까워지는 현상을 적절히 구현함 |
| `milddle3Bio/10_human_heredity_summary_lab.html` | 양호 | 단일유전자 활동의 한계를 밝히고 ABO 복대립유전 계산을 적절히 구현함 |
| `milddle3BioAdv/05_nerve_hormone_speed_lab.html` | 오류 | 모든 호르몬이 거리와 무관하게 정확히 60초에 도달한다고 하고 신경과의 속도비를 고정함. 혈류·호르몬 종류·수용체 반응을 무시함 |
| `milddle3BioAdv/06_division_cycle_lab.html` | 개선 필요 | 세포 종류별 분열 주기를 단일값으로 고정함. 배양 조건과 세포주에 따른 범위, 성장곡선 단계 구분이 필요함 |
| `milddle3BioAdv/07_chromosome_number_lab.html` | 오류 | `어떤 생물이든` 생식세포 염색체 수가 체세포의 정확한 절반이라고 일반화함. 이배체·정상 감수분열 조건을 명시해야 함 |

### 화학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `milddle3Chem/01_mass_conservation_lab.html` | 양호 | 밀폐계에서 반응 전후 총질량이 보존된다는 핵심 내용이 적절함 |
| `milddle3Chem/02_open_container_lab.html` | 개선 필요 | 반응물 총량과 CO₂ 손실량을 항상 정비례시킴. 베이킹소다·식초의 조성비와 한계 반응물 조건을 밝혀야 함 |
| `milddle3Chem/03_iron_rust_lab.html` | 개선 필요 | 녹에 의한 질량 증가를 시간당 0.15g의 직선으로 고정함. 수분·산소·표면적과 반응속도 저하를 포함한 단순 모형 표시가 필요함 |
| `milddle3Chem/04_definite_proportions_lab.html` | 양호 | 산화구리에서 구리:산소의 약 4:1 질량비와 생성물 질량 계산이 활동 범위에서 적절함 |
| `milddle3Chem/05_limiting_reactant_lab.html` | 양호 | 산소 공급량을 고정한 조건에서 반응 구리와 남는 구리를 구분하는 한계 반응물 모형이 적절함 |
| `milddle3Chem/06_water_electrolysis_lab.html` | 개선 필요 | 물 분자식만으로 기체 부피비 2:1을 설명함. 기체의 같은 온도·압력 조건과 전해질·전극 조건을 보완해야 함 |
| `milddle3Chem/07_exothermic_lab.html` | 오류 | 열용량·산소 공급·열손실 조건 없이 철가루 양과 손난로 온도 상승을 정확히 정비례시킴 |
| `milddle3Chem/08_endothermic_lab.html` | 개선 필요 | 물 200g만의 열용량으로 질산암모늄 양과 온도 하강을 직선화함. 용액 열용량·용해도·열교환 조건이 필요함 |
| `milddle3Chem/09_combustion_energy_lab.html` | 양호 | 등유의 완전연소·고정 발열량 조건에서 연료량과 발생 열량의 관계가 적절함 |
| `milddle3Chem/10_reaction_rules_lab.html` | 오류 | 생성물÷시료 질량비 1.43만으로 미지 물질을 철로 단정함. 같은 비를 만드는 다른 반응을 배제할 수 없음 |
| `milddle3ChemAdv/02_mass_loss_calc_lab.html` | 개선 필요 | CO₂ 발생량을 베이킹소다 양에 고정 비례시킴. 식초가 충분하고 반응이 완결된다는 조건을 명시해야 함 |
| `milddle3ChemAdv/07_heatpack_temp_lab.html` | 오류 | 철가루 10g당 ΔT 22℃를 선형 외삽해 실제 제조 계산이라고 함. 계 전체 열용량·산소·열손실·반응속도가 빠짐 |
| `milddle3ChemAdv/08_coldpack_limit_lab.html` | 오류 | 질산암모늄 수용액이 0℃에서 얼어 온도가 더 내려가지 않는다고 함. 용질은 어는점을 낮추며 냉각팩은 0℃ 아래도 가능함 |

### 지구과학 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `milddle3Geo/01_atmosphere_layers.html` | 오류 | ISA를 120km 열권까지의 `실제 기온 분포`라 하며 85km 위를 고정 선형식으로 외삽함. 열권 온도는 태양활동 등에 크게 좌우됨 |
| `milddle3Geo/02_pressure_wind.html` | 오류 | 100km당 기압차만으로 풍속을 `0.45×기압차`로 고정하고 정비례라 결론 냄. 전향력·마찰·공기밀도 등이 빠짐 |
| `milddle3Geo/03_clouds_precipitation.html` | 오류 | 강수가 항상 얼음으로 시작하고 단일 기온이 0℃ 이하면 눈, 0~3℃면 진눈깨비라고 결정함. 온층 깊이와 온도 수직분포·따뜻한 비 과정이 빠짐 |
| `milddle3Geo/04_air_mass_front.html` | 개선 필요 | 기단과 한랭·온난전선의 구름·강수 폭을 고정 유형으로 제시함. 계절·수증기·안정도·이동속도에 따른 변화를 안내해야 함 |
| `milddle3Geo/05_weather_forecast.html` | 오류 | 출처 없는 `90−0.07×저기압 거리+전선 25%p`를 과거 관측의 강수확률 경험식이라고 제시함 |
| `milddle3Geo/06_star_magnitude.html` | 양호 | 거리 지수와 겉보기·절대등급 관계를 활동 범위에서 적절히 계산함 |
| `milddle3Geo/07_star_color.html` | 오류 | 태양의 최대복사 파장이 약 500nm이므로 노랗게 보인다고 설명함. 별의 보이는 색은 가시광 전체 스펙트럼과 시각 반응으로 정해지며 태양광은 본질적으로 흰색임 |
| `milddle3Geo/08_galaxy_scale.html` | 양호 | 해왕성 궤도 기준 태양계와 우리은하의 축척비 및 태양계 위치 계산이 대체로 적절함 |
| `milddle3Geo/09_universe_scale.html` | 개선 필요 | 풍선 표면 모형의 차원·중심 해석 한계 없이 실제 공간 팽창과 직접 동일시함. 묶인 계와 우주 팽창의 차이도 안내해야 함 |
| `milddle3Geo/10_space_exploration_reason.html` | 오류 | 인공위성은 지구 궤도까지만 간다고 정의하고, 에어쿠션 운동화·화재경보기 등을 우주탐사 파생기술로 단정함 |
| `milddle3GeoAdv/02_altitude_pressure_lab.html` | 개선 필요 | 기압이 `일정한 높이마다 절반`으로 감소하고 끓는점이 고도에 직선 비례한다고 설명함. 제한 구간의 근사임을 표시해야 함 |
| `milddle3GeoAdv/05_isobar_wind_lab.html` | 오류 | 등압선 간격과 풍속을 정확한 반비례로 두고 바람 세기는 기압경도만 결정한다고 함. 전향력·마찰·곡률·공기밀도를 무시함 |
| `milddle3GeoAdv/06_apparent_absolute_lab.html` | 양호 | 거리 지수와 겉보기·절대등급의 부호·순위 해석을 적절히 구현함 |
| `milddle3GeoAdv/09_hubble_age_lab.html` | 개선 필요 | Hubble 상수를 단일값으로 고정하고 `거리÷속도`를 우주 나이로 연결함. 가까운 은하의 고유운동과 우주 팽창사의 감속·가속을 더 명확히 구분해야 함 |

### 물리 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `milddle3Phy/01_uniform_motion_lab.html` | 양호 | 2.0m/s 등속 조건에서 거리–시간 직선과 기울기의 의미가 적절함 |
| `milddle3Phy/02_speed_conversion_lab.html` | 양호 | km/h와 m/s의 3.6 환산 관계가 정확함 |
| `milddle3Phy/03_graph_area_lab.html` | 양호 | 구간별 일정 속력의 속력–시간 그래프 넓이와 이동 거리 관계가 적절함 |
| `milddle3Phy/04_air_resistance_lab.html` | 개선 필요 | 고정한 질량·단면적·항력계수를 물체의 `실제 값`이라고 단정함. 자세·형상·깃털 변형과 부력·공기 조건의 한계를 표시해야 함 |
| `milddle3Phy/05_gravity_acceleration_lab.html` | 양호 | 공기저항 없는 자유낙하 조건에서 `v=gt`, `h=½gt²` 관계가 적절함 |
| `milddle3Phy/06_freefall_ride_lab.html` | 양호 | 공기저항 없는 낙하에서 높이와 도달 속력의 제곱근 관계가 적절함 |
| `milddle3Phy/07_pendulum_energy_lab.html` | 양호 | 비선형 진자 방정식과 에너지 보존으로 속력·주기를 일관되게 계산함 |
| `milddle3Phy/08_energy_conservation_lab.html` | 양호 | 마찰 없는 1kg 수레의 위치·운동에너지 합을 적절히 계산함 |
| `milddle3Phy/09_friction_loss_lab.html` | 양호 | 정해진 빗면과 운동마찰 조건에서 마찰 일, 열, 남은 운동에너지 계산이 일관됨 |
| `milddle3Phy/10_projectile_motion_lab.html` | 양호 | 공기저항 없는 수평투사에서 수평·수직 운동의 독립성과 낙하 시간을 적절히 구현함 |
| `milddle3PhyAdv/06_freefall_speed_design_lab.html` | 개선 필요 | 식 자체와 오차 안내는 적절하지만 자유낙하 속력 역산을 실제 놀이기구 설계자의 높이 결정 과정과 동일시하는 표현은 완화가 필요함 |

### 이번 묶음의 우선 수정 순서

1. `milddle3ChemAdv/08_coldpack_limit_lab.html`의 0℃ 고정 하한을 제거하고 용액의 어는점 내림과 실제 열수지를 반영한다.
2. `milddle3Bio/05_hormones_lab.html`에서 일반 식후 혈당과 75g 경구당부하검사를 구분하고 진단·확진 조건을 정확히 쓴다.
3. `milddle3Geo/05_weather_forecast.html`의 출처 없는 강수확률 공식을 `교육용 가상 모형`으로 명시하거나 검증된 자료 기반 활동으로 교체한다.
4. `milddle3ChemAdv/07_heatpack_temp_lab.html`과 `milddle3Chem/07_exothermic_lab.html`의 철가루 양–온도 선형식을 열량·열용량·열손실 모형으로 바꾼다.
5. `milddle3Geo/01_atmosphere_layers.html`, `02_pressure_wind.html`, `03_clouds_precipitation.html`, `07_star_color.html`의 `실제·정확히·항상` 표현과 핵심 과학 모형을 수정한다.
6. 48개 파일의 입력 요소에 접근성 이름을 추가하고 실제 모바일 브라우저에서 터치·키보드·대화상자·캔버스를 후속 검사한다.

## 8차 일괄 검증: 고등학교 13개 폴더

- 범위: `high1Integ` 36개, `high2Bio` 13개, `high2Chem` 11개, `high2Geo` 16개, `high2Phy` 18개, 고3 선택 과목 8개 폴더 67개
- 합계: HTML 161개 (`units.json` 12개 제외)
- 이번 묶음 판정: 오류 7개, 개선 필요 68개, 양호 86개
- 기술 검사: 161개 모두 JavaScript 구문 통과, 중복 ID·존재하지 않는 고정 DOM 참조·외부 스크립트·접근성 이름 없는 입력 요소 없음. 161개 모두 반응형 미디어 쿼리 포함
- 제한: Chromium 설치가 차단된 환경이므로 실제 클릭·애니메이션·모바일 렌더링은 수행하지 못했다. 소스 정적 검사와 과학 내용 검토 결과다.
- 중복: `high1Integ`의 번호형 18개와 `integ1_*`/`integ2_*` 18개는 각각 완전히 같은 파일이다. 아래 판정 건수에는 실제 파일 수대로 두 번 포함했다.

### 즉시 수정할 오류 7개

| 파일 | 핵심 오류 |
|---|---|
| `high2Geo/08_geologic_time_fossil_lab.html` | 여러 화석이 함께 나온 층의 연대를 교집합이 아니라 합집합으로 계산한다. 예를 들어 시조새(150~145 Ma)와 공룡(230~66 Ma)의 공존 범위는 150~145 Ma여야 하지만 코드의 `min(start), max(end)`는 230~66 Ma를 낸다. |
| `high2Geo/16_hubble_law_lab.html` | 최대 1,400 Mpc에서도 `z=H₀d/c`와 `v=cz`를 그대로 사용한다. 끝점은 z≈0.327이라 저적색편이 근사를 정밀 측정처럼 쓰기 어렵다. 우주론적 적색편이-거리 관계 또는 낮은 z 범위로 제한해야 한다. |
| `high3ChemReaction/03_titration_buffer_lab.html` | 완충 비교 모드에서 0.1 M HCl의 pH가 NaOH를 얼마나 넣어도 항상 1로 남는다(`add * 0`). 순수한 물도 첨가 뒤 부피를 고려하지 않는다. 강산·강염기의 중화와 전체 부피로 다시 계산해야 한다. |
| `high3ChemReaction/06_galvanic_cell_lab.html` | 서로 다른 전자 수의 반쪽 반응을 조합할 때 반응식 계수를 반응지수 Q에 반영하지 않는다. Zn/Ag 전지는 `Q=[Zn²⁺]/[Ag⁺]²`여야 하나 현재는 Ag⁺를 1제곱으로 사용해 농도 효과가 틀린다. 최소공배수로 전체 반응과 n을 구성해야 한다. |
| `high3MatterEnergy/06_phase_diagram_lab.html` | 삼중점·임계점 외의 상경계가 임의의 로그/직선식인데 실제 상평형 그림과 상태 판정처럼 표시된다. 물질별 검증된 Antoine·Clausius–Clapeyron 자료 또는 명시적인 가상 모형이 필요하다. |
| `high3PlanetUniverse/01_solar_planets_lab.html` | 위성 수가 목성 95, 토성 146, 천왕성 28로 오래됐다. 2026년 7월 NASA 공개값은 각각 115, 293, 29이며 해왕성은 16이다. 수치에 기준일을 붙이고 갱신해야 한다. |
| `high3PlanetUniverse/02_planet_atmosphere_lab.html` | 평형 온도에 고정 온실효과를 더해 `실제 표면 온도`라 하고 목성에도 고체 표면 온도처럼 적용한다. 기체행성은 기준 압력면·구름꼭대기 온도를 구분하고, 온실효과를 단순 덧셈 상수로 일반화하지 않아야 한다. |

천문 수치는 NASA Space Place의 2026-07-31 갱신 자료를 기준으로 대조했다: <https://spaceplace.nasa.gov/how-many-moons/en/>.

### 폴더별 판정 요약

| 폴더 | 오류 | 개선 필요 | 양호 | 주요 개선 대상 |
|---|---:|---:|---:|---|
| `high1Integ` | 0 | 18 | 18 | 빅뱅 핵합성, 달걀 충격, 해양저 확장, 항생제 선택, 용해열, 온실효과, 유도전압, 에너지 효율, 감염병 모형의 가정·범위 표시. 각 항목은 동일한 복제본에도 같은 판정 |
| `high2Bio` | 0 | 8 | 5 | `01`, `02`, `05`, `06`, `09`, `10`, `11`, `13`의 고정 생리값·단순 면역/교차/계통 모형을 대표값 또는 교육용 모형으로 표시 |
| `high2Chem` | 0 | 1 | 10 | `06_molecular_shape_lab.html`에서 전기장 속 극성분자가 모두 한 방향으로 정렬하는 표현을 열운동과 통계적 배향을 포함하도록 완화 |
| `high2Geo` | 2 | 9 | 5 | 오류 2개 외 `02`~`06`, `09`, `10`, `14`, `15`의 기상·기후·암석·별 진화 대표 모형과 자료 기준일 보완 |
| `high2Phy` | 0 | 4 | 14 | `10`, `12`, `15`, `17`의 자성 힘·쌍극자 코일·광전류·다이오드 모형의 적용 범위와 근사 표시 |
| `high3CellMetabolism` | 0 | 6 | 2 | `01`~`04`, `06`, `07`의 세포 크기·수송 속도·세포 주기·효소 곡선·효모 호흡·광합성 기포값을 대표 모형으로 명시 |
| `high3ChemReaction` | 2 | 3 | 3 | 오류 2개 외 `01`, `04`, `08`의 속도식·공통 이온·연료전지 효율에 사용한 단순 가정 표시 |
| `high3EarthSystem` | 0 | 6 | 2 | `01`, `02`, `04`, `06`~`08`의 층상 구조·지진파·에크만각·대순환·습윤감률·탄소 흐름 대표값 보완 |
| `high3EMQuantum` | 0 | 4 | 4 | `02` 물의 유전율 주파수 의존성, `05` 고정 효율, `06` 100 kV에서 무시한 상대론 보정, `08` 임의 레이저 임계값 표시 |
| `high3Genetics` | 0 | 3 | 4 | `03`의 실제 유도물질 allolactose, `05`의 1 cM≈1% 한계와 50% 상한, `06`의 침투도·표현도·가계도 모호성 보완 |
| `high3MatterEnergy` | 1 | 1 | 6 | 오류 외 `05_intermolecular_force_lab.html`에서 녹는점·끓는점 바로 위/아래와 상공존을 구분 |
| `high3Mechanics` | 0 | 1 | 11 | `08_heat_engine_lab.html`의 기관별 효율을 온도와 무관한 카르노 효율의 고정 비율로 둔 임의 모형 표시 |
| `high3PlanetUniverse` | 2 | 4 | 2 | 오류 외 `03`~`06`의 궤도 경사·이심률·태양 자전 기준·Jeans 질량·거리사다리 적용 범위 보완 |
| **합계** | **7** | **68** | **86** |  |

### 파일별 개선 판정

- `high1Integ`: `02_big_bang_helium`, `06_impulse_egg_drop`, `08_seafloor_spreading`, `10_natural_selection_antibiotic`, `12_exo_endo_pack`, `13_greenhouse_blanket`, `15_electromagnetic_induction`, `16_energy_efficiency_relay`, `17_epidemic_spread`와 각각의 동일 복제본. 화면에 이미 일부 가정이 있으나, 결과를 실제 측정·보편 법칙으로 오해하지 않도록 수치 옆에 모형 범위를 지속 표시해야 한다.
- `high2Bio`: `01_digestive_enzyme_lab.html`은 모든 효소에 같은 온도 곡선을 적용하고, `02_exercise_organ_systems_lab.html`은 고정 심박수·산소섭취 관계를 쓴다. `05_nerve_conduction_lab.html`, `06_synapse_drug_lab.html`, `09_immune_vaccine_lab.html`은 개인·신경·약물·면역 반응을 단일 곡선으로 단순화한다. `10_karyotype_lab.html`, `11_meiosis_gamete_diversity_lab.html`, `13_phylogenetic_tree_lab.html`은 각각 대략적 동원체/유전자 수, 교차 위치 한 곳, 단순 형질 유사도 군집이라는 한계를 표시해야 한다.
- `high2Geo`: `02_thermohaline_lab.html`의 밀도 임계값, `03_midlatitude_cyclone_lab.html`의 고정 전선 날씨, `04_typhoon_wind_lab.html`의 이상화한 태풍장, `05_enso_lab.html`의 단일 ENSO 모형, `06_climate_forcing_lab.html`의 고정 기후민감도와 2024 CO₂, `09_magma_igneous_rock_lab.html`의 규산 함량 중심 분류, `10_geopark_korea_lab.html`의 시점 의존 목록, `14_stellar_evolution_lab.html`의 질량별 단일 경로, `15_galaxy_classification_lab.html`의 형태만으로 정한 분류 한계를 보완한다.
- `high2Phy`: `10_magnetic_materials_lab.html`은 축상 자기장과 균일 감수율로 저울 힘을 계산하고, `12_electromagnetic_induction_lab.html`은 자석을 점쌍극자·코일을 무두께 고리로 근사한다. `15_photoelectric_effect_lab.html`은 전자 운동에너지 분포와 광전류를 직선으로 단순화하며, `17_pn_diode_lab.html`은 고정 온도·직렬저항 조건의 이상 다이오드 모형이다.
- `high3CellMetabolism`: `01_cell_organelle_lab.html`, `02_membrane_transport_lab.html`, `03_cell_cycle_lab.html`, `04_enzyme_kinetics_lab.html`, `06_yeast_fermentation_lab.html`, `07_photosynthesis_rate_lab.html`은 각각 대표 크기·상대 수송속도·고정 20시간 주기·단일 pH/온도 곡선·30분 호흡량·기포수를 실제 보편값처럼 읽히지 않게 해야 한다.
- `high3ChemReaction`: `01_reaction_rate_lab.html`의 Arrhenius 상수·반응차수, `04_solubility_ksp_lab.html`의 과량 공통이온 근사, `08_fuel_cell_lab.html`의 고정 내부저항·효율을 명시적인 모형값으로 표시한다.
- `high3EarthSystem`: `01_earth_formation_lab.html`, `02_seismic_interior_lab.html`, `04_ekman_transport_lab.html`, `06_global_circulation_lab.html`, `07_precipitation_lab.html`, `08_carbon_cycle_lab.html`은 각각 대표 층 경계, 일정 파속, 이상적 표면 45° 흐름, 비회전 1세포 모형, 고정 습윤감률, 출처 연도 없는 탄소 저장량·흐름을 보완한다.
- `high3EMQuantum`: `02_dielectric_capacitor_lab.html`, `05_transformer_lab.html`, `06_matter_wave_lab.html`, `08_laser_energy_level_lab.html`에 주파수·손실·부하 조건, 효율 근거, 100 kV 상대론 보정, 임의 발진 임계값을 각각 표시한다.
- `high3Genetics`: `03_gene_regulation_lab.html`은 젖당 자체가 아니라 allolactose가 억제 단백질에 결합함을 구분한다. `05_gene_linkage_lab.html`은 짧은 거리에서만 1% 재조합≈1 cM이고 재조합률은 50%를 넘지 않음을 설명한다. `06_human_pedigree_lab.html`은 가계도만으로 유전 양식이 유일하지 않을 수 있음을 안내한다.
- `high3MatterEnergy/05_intermolecular_force_lab.html`: 녹는점·끓는점에서 단일 상으로 즉시 바뀌는 판정을 고쳐 상공존을 표시한다.
- `high3Mechanics/08_heat_engine_lab.html`: 증기·가솔린 기관의 효율을 카르노 한계의 각각 42%, 55%로 고정한 값은 실제 기관의 보편 효율이 아니라 비교용 가상값이라고 명시한다.
- `high3PlanetUniverse`: `03_exoplanet_detection_lab.html`은 원형·edge-on·중앙 통과 가정, `04_solar_observation_lab.html`은 자전주기의 항성/회합 기준, `05_star_formation_lab.html`은 Jeans 질량과 수명식의 근사, `06_cosmic_distance_lab.html`은 거리사다리의 적용 범위와 H₀ 고정값을 보완한다.

### 양호 파일

- `high1Integ`: `01`, `03`, `04`, `05`, `07`, `09`, `11`, `14`, `18`과 각각의 동일 복제본 18개
- `high2Bio`: `03`, `04`, `07`, `08`, `12` 5개
- `high2Chem`: `01`~`05`, `07`~`11` 10개
- `high2Geo`: `01`, `07`, `11`, `12`, `13` 5개
- `high2Phy`: `01`~`09`, `11`, `13`, `14`, `16`, `18` 14개
- 고3: `high3CellMetabolism`의 `05`, `08`; `high3ChemReaction`의 `02`, `05`, `07`; `high3EarthSystem`의 `03`, `05`; `high3EMQuantum`의 `01`, `03`, `04`, `07`; `high3Genetics`의 `01`, `02`, `04`, `07`; `high3MatterEnergy`의 `01`~`04`, `07`, `08`; `high3Mechanics`의 `01`~`07`, `09`~`12`; `high3PlanetUniverse`의 `07`, `08`

`양호`는 정적 검사에서 중대한 문제를 찾지 못했다는 뜻이며, 실제 브라우저에서 모든 조작 경로가 정상이라는 보증은 아니다.

### 고등학교 묶음 우선 수정 순서

1. 화석 공존 연대의 교집합 계산, 완충 비교의 NaOH 중화, 갈바니 전지의 반응지수·전자 수를 먼저 고친다.
2. 행성 위성 수를 기준일과 함께 갱신하고 기체행성의 `표면 온도` 표현을 수정한다.
3. 먼 은하의 적색편이 계산 범위를 낮추거나 우주론적 거리식을 사용한다.
4. 임의 상평형 곡선을 검증된 물성 자료로 교체하거나 화면 전체에 `가상 모형`임을 표시한다.
5. 68개 개선 파일에서 대표값·고정 효율·고정 생리 반응·이상화 조건을 결과 가까이에 표시한다.
6. 실제 모바일 브라우저에서 버튼 연속 클릭, 키보드, 캔버스 크기, 애니메이션 종료, 360px 폭을 후속 검사한다.

## 9차 일괄 검증: 대학교 2개 폴더

- 범위: `univPhysics` 2개, `univGenChem` 3개
- 합계: HTML 5개
- 이번 묶음 판정: 오류 0개, 개선 필요 3개, 양호 2개
- 기술 검사: 5개 모두 JavaScript 구문 통과, 중복 ID·존재하지 않는 고정 DOM 참조·접근성 이름 없는 입력 요소 없음. 5개 모두 반응형 미디어 쿼리 포함
- 제한: 실제 브라우저의 클릭·애니메이션·모바일 렌더링은 검증 환경의 Chromium 설치 제한으로 수행하지 못했다.

### 파일별 판정

| 파일 | 판정 | 핵심 결과 |
|---|---|---|
| `univPhysics/01_free_fall_g_lab.html` | 개선 필요 | 항력을 포함한 수치적분, `h-t²` 최소제곱 및 계통오차 비교는 적절하다. 다만 표준중력 9.80665 m/s²를 실험 장소의 `참값`처럼 표시하고, 두 g 추정값 차이를 각 표준오차의 최댓값과 비교한다. 지역 중력값을 기준으로 쓰고 차이의 불확도는 독립 측정이면 `√(σ₁²+σ₂²)`로 결합해야 한다. 일정한 구의 항력계수·공기밀도 근사도 표시한다. |
| `univPhysics/02_friction_coefficient_lab.html` | 개선 필요 | `μₛ=tanθₛ`와 `a/cosθ=g tanθ-gμₖ`의 선형화는 맞다. 그러나 나무·강철·얼음의 단일 계수를 보편적인 `문헌값`처럼 사용한다. 마찰계수는 표면 상태·온도·윤활·속도에 크게 의존하며, `μₖ=-B/A`의 불확도 계산에는 회귀 기울기와 절편의 공분산도 포함해야 한다. |
| `univGenChem/01_density_metal_id_lab.html` | 양호 | 20°C 금속 밀도, 질량/치환 부피, 유효숫자와 작은 ΔV의 상대오차 설명이 일관된다. 구문·요소 참조도 정상이다. |
| `univGenChem/02_limiting_reagent_lab.html` | 개선 필요 | Zn+2HCl 양론, 수증기압 보정, 이상기체 부피 계산은 맞다. 다만 관측 수득률 감소를 `누출·잔류`로 함께 모델링하면서 잔류 Zn은 100% 반응 기준으로 계산해 Zn 한계 조건에서 항상 0이 된다. 손실 원인을 기체 누출만으로 한정하거나, 미반응 Zn도 수득률에 맞춰 계산해야 한다. |
| `univGenChem/03_calorimetry_lab.html` | 양호 | 강산·약산 중화열, 한계 몰수, 용액 열용량과 몰 엔탈피 계산이 일관되며 열량계 흡수·주변 열손실로 인한 계통오차도 설명한다. |

### 대학 묶음 권장 수정 순서

1. 자유낙하 실험에서 `참값`을 표준중력과 지역 중력값으로 구분하고 두 측정값 차이의 결합 불확도를 사용한다.
2. 마찰계수 표에 재료명뿐 아니라 표면 상태·온도 조건을 붙이고 회귀 공분산을 포함해 `μₖ` 불확도를 계산한다.
3. 한계반응물 실험의 수득률 손실 원인과 잔류 Zn 계산을 같은 모형으로 맞춘다.
4. 실제 브라우저에서 360px 화면, 터치·키보드 조작, 애니메이션 종료와 반복 측정 흐름을 확인한다.

## 전체 검증 완료

현재 Drive 루트의 교과 폴더 50개, HTML 405개를 모두 검증했다. 루트의 `index.html`은 실험 목록·진입 페이지이므로 이번 교과 실험 파일 판정 건수에서는 제외했다.
