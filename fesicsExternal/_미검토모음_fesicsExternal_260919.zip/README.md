# 미검토 파일 모음 (2026-09-19)

이 압축본은 fesicsExternal 가운데 **내용(과학·수학) 재검증이 아직 완료되지 않은 파일**만 모은 것입니다.
2026-09-14 상세 검증(503개)과 2026-09-19 수정 반영이 끝난 6개 폴더(fesicsLabs, fesicsMathLabs, zerolabMathHigh, univGenBio, univMechanics, univEM)는 제외했습니다.

## 01_예전405개_내용재검증필요 — 50개 폴더, HTML 
- 2026-09-12 검증(오류 83 / 개선 165 / 양호 157) 이후 2026-09-14에 전체가 다시 수정된 파일들.
- 자동 검사(JS 구문·중복 id·DOM 참조·viewport·@media·입력 label)는 통과.
- 09-12 보고서의 오류 83개가 항목별로 모두 고쳐졌는지, 수정 과정에서 새 오류가 생겼는지는 **아직 확인하지 않음**.
- 대조 기준: _참고보고서/_검증보고서_fesicsExternal_HTML_260912.md

## 02_Tech99개_미검증 — 5개 폴더, HTML 
- elem56Tech(33), milddle1Tech(8), milddle2Tech(8), milddle3Tech(10), highTechHome(40). 2026-09-15 추가.
- 어떤 검증 보고서에도 포함된 적 없음. 2026-09-19에 label-for 연결(419건)만 수정.

## _참고보고서
- _검증보고서_fesicsExternal_HTML_260912.md — 405개 원 판정
- _중간진행보고서_fesicsExternal_예전405개재검증_260915.md — 재검증 중단 시점 현황
- _수정반영보고서_fesicsExternal_추가검증반영_260919.md — 이번 수정 내역